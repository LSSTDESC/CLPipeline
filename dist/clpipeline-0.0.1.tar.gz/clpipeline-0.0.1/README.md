# CLPipeline
Repository devoted to the Cluster working group from the DESC-LSST collaboration

To install the new CECI version, use 
`pip install git+https://github.com/hellebore74/ceci`

To build the package so it can be imported into a python file, run
```
python -m build
```

